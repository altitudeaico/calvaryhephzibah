# PTZ Camera — Local Live Preview

A single HTML file that embeds the camera's own web page (live picture +
joystick controls) so you get one clean window instead of the camera's page
opening separately.

## Why this has to run locally — please read this bit

This file works by loading `http://192.168.0.206` inside itself. Browsers
block that combination whenever the *outer* page is HTTPS (secure) — that's
why this can't just be a page on `calvaryhephzibah.co.uk` like everything
else Control Room has. This file has no `https://` in front of it at all
when you open it directly, so that rule never applies and the camera's page
loads normally.

**This means: don't upload this to the website. Don't put it behind a link
on calvaryhephzibah.co.uk.** The moment it's served over HTTPS, it stops
working, for exactly the same reason the Control Room preview panel
couldn't show it directly. Keep it as a local file.

## How to use it

1. Unzip this on the **box computer** — the one wired to the camera. This
   will not show anything on any other computer, since it depends on being
   able to reach `192.168.0.206` on the local network.
2. Double-click `camera-preview.html`. It'll open in your default browser.
3. You should see the camera's live picture and joystick controls, inside
   a clean dark window instead of the camera's own page chrome.
4. Bookmark it, or drag it to the dock/desktop, so it's a one-click open
   next time — no re-downloading needed.

## What this is and isn't

- **Is:** the camera's own page, embedded in a nicer frame. If the camera's
  page changes (firmware update, login prompt, etc.), this will show
  whatever that page shows, including a login screen if you get logged out.
- **Isn't:** a real Control Room feature, and isn't the low-latency native
  NDI view from the desktop-app proof-of-concept. This is the "get it
  working today, cheaply" version. If you want it properly folded into
  Control Room itself with matching design and no separate window, that's
  a further step — flag it and we'll scope it.
