# Calvary NDI Viewer — proof of concept

**What this proves:** a desktop app can receive the Tenveo camera's NDI feed
directly — the same feed OBS already pulls in — without going through
YouTube, a relay server, or any browser mixed-content workaround. If this
runs and shows live video, the "desktop app" idea for Control Room's preview
is confirmed as genuinely workable, and the low latency you'll see is what a
real integrated version would give you.

**What this is not:** a finished tool. No Control Room integration, no
styling to match the app, no PTZ controls. Just: find NDI sources on the
network, pick one, show it, report the frame rate.

**Important — I couldn't test this myself.** This was written in a sandbox
with no macOS, no camera, and no access to your church's network, against
[grandiose's](https://github.com/Streampunk/grandiose) documented API. The
first time you run this on the Mac Mini *is* the real test. If something
doesn't work, copy the exact error text back and I'll fix it — that's
expected to take at least one round of debugging, not a sign anything went
wrong on your end.

---

## Setup (on the Mac Mini)

You'll need [Node.js](https://nodejs.org) installed (LTS version). If
`node -v` in Terminal shows a version number, you're set — skip to Install.

```bash
cd ~/Downloads/ndi-viewer-poc      # wherever you unzipped this
npm install
```

`npm install` does two things: installs Electron, and installs `grandiose`
(the NDI binding), which needs to compile a small native module. If that
compile step fails, you likely need Xcode's command line tools:

```bash
xcode-select --install
```

...then run `npm install` again.

**`postinstall` runs `electron-rebuild` automatically.** This matters because
Electron bundles its own Node.js internally, which isn't quite the same as
your system Node — a native module like `grandiose` has to be rebuilt
specifically for Electron's version, or the app will fail to start with a
"module version mismatch" error. If you ever see that error, run:

```bash
npx electron-rebuild -f -w grandiose
```

## Run it

```bash
npm start
```

A dark window opens. Click **"Find NDI sources"** — this only finds
anything if the Mac Mini can actually see the camera on the network (the
`192.168.0.x` side, per the [PTZ camera guide](../calvary-os/ptz-camera.html)
— if OBS can already see the camera as an NDI source, this app should too,
since they're doing the same kind of search on the same network).

Pick the Tenveo entry from the dropdown, click **Connect**. Video should
appear within a second or two, with a live fps counter in the top right.

## Known limitations (proof-of-concept, not production)

- **Frame transport is naive.** Every full frame gets sent from the main
  process to the window over Electron's IPC, uncompressed. At the camera's
  real resolution this is a lot of data per second — if it stutters or lags,
  that's very likely this transport method, not a sign NDI itself is slow. A
  real version would either render inside the main process's own window
  directly or throttle/downscale the preview resolution.
- **No reconnect logic.** If the camera drops off the network or changes IP
  (the guide mentions routers sometimes reassign it), you'll need to
  disconnect and reconnect manually.
- **No audio.** Video only, on purpose — this was about proving low-latency
  video is possible, not building the whole pipeline.
- **`grandiose` itself is a low-maintenance/prototype-stage library** (its
  own docs say as much). Fine for this proof of concept; if we move to a
  real build, worth evaluating alternatives at that point too.

## If it doesn't work at all

- **"No sources found"** → almost always a networking issue, not this app.
  Confirm OBS can currently see the camera as an NDI source first. If OBS
  can't see it either, work through the Network Setup section of the PTZ
  guide before coming back to this.
- **App won't start / native module error** → run the `electron-rebuild`
  command above, and make sure Xcode command line tools are installed.
- **Video appears garbled/wrong colours** → tell me exactly what it looks
  like (green tint, diagonal tearing, etc.) — that's usually a sign the
  color format constant needs adjusting for your camera's exact output, an
  easy fix once I know the symptom.

## Files

```
main.js        — Electron main process: finds/receives NDI (the actual native work)
preload.js     — safe bridge between main process and the window
renderer.html  — the window's UI
renderer.js    — draws incoming frames to a canvas, handles buttons
package.json   — dependencies (electron, grandiose)
```
