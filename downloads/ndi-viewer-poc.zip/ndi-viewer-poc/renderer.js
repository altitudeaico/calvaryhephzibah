// renderer.js — no Node access here (contextIsolation is on, see
// preload.js). Everything native happens in main.js; this file just
// asks for sources/frames over the `window.ndi` bridge and paints
// whatever comes back.

const refreshBtn = document.getElementById('refresh-btn');
const sourceSelect = document.getElementById('source-select');
const connectBtn = document.getElementById('connect-btn');
const disconnectBtn = document.getElementById('disconnect-btn');
const statusEl = document.getElementById('status');
const canvas = document.getElementById('canvas');
const placeholder = document.getElementById('placeholder');
const ctx = canvas.getContext('2d');

let sources = [];
let connected = false;

function setStatus(text, kind) {
  statusEl.textContent = text;
  statusEl.className = kind || '';
}

refreshBtn.addEventListener('click', async () => {
  refreshBtn.disabled = true;
  setStatus('searching for NDI sources (a few seconds)…');
  try {
    sources = await window.ndi.findSources(4000);
    sourceSelect.innerHTML = '';
    if (sources.length === 0) {
      sourceSelect.innerHTML = '<option>No sources found</option>';
      sourceSelect.disabled = true;
      connectBtn.disabled = true;
      setStatus('no NDI sources found on this network', 'error');
    } else {
      sources.forEach((s, i) => {
        const opt = document.createElement('option');
        opt.value = i;
        opt.textContent = s.name;
        sourceSelect.appendChild(opt);
      });
      sourceSelect.disabled = false;
      connectBtn.disabled = false;
      setStatus(`found ${sources.length} source${sources.length === 1 ? '' : 's'}`);
    }
  } catch (err) {
    setStatus('error: ' + err.message, 'error');
  } finally {
    refreshBtn.disabled = false;
  }
});

connectBtn.addEventListener('click', async () => {
  const idx = Number(sourceSelect.value);
  const source = sources[idx];
  if (!source) return;

  connectBtn.disabled = true;
  setStatus('connecting to ' + source.name + '…');
  try {
    await window.ndi.connect(source);
    connected = true;
    placeholder.style.display = 'none';
    canvas.style.display = 'block';
    disconnectBtn.disabled = false;
    setStatus('connecting… waiting for first frame', 'live');
  } catch (err) {
    setStatus('connect failed: ' + err.message, 'error');
    connectBtn.disabled = false;
  }
});

disconnectBtn.addEventListener('click', async () => {
  await window.ndi.disconnect();
  connected = false;
  disconnectBtn.disabled = true;
  connectBtn.disabled = false;
  canvas.style.display = 'none';
  placeholder.style.display = 'block';
  placeholder.textContent = 'Disconnected.';
  setStatus('idle');
});

window.ndi.onFrame((frame) => {
  if (!connected) return;

  if (canvas.width !== frame.width || canvas.height !== frame.height) {
    canvas.width = frame.width;
    canvas.height = frame.height;
  }

  // frame.buffer arrives as a Node Buffer over IPC, which shows up
  // here as a Uint8Array-like structure. ImageData wants a
  // Uint8ClampedArray of the same RGBA byte layout.
  try {
    const clamped = new Uint8ClampedArray(frame.buffer.buffer || frame.buffer);
    const imageData = new ImageData(clamped, frame.width, frame.height);
    ctx.putImageData(imageData, 0, 0);
  } catch (err) {
    setStatus('frame draw error: ' + err.message, 'error');
    return;
  }

  if (frame.fps !== null && frame.fps !== undefined) {
    setStatus(`live — ${frame.fps} fps`, 'live');
  }
});

window.ndi.onError((message) => {
  setStatus('NDI error: ' + message, 'error');
  connected = false;
  disconnectBtn.disabled = true;
  connectBtn.disabled = false;
});
