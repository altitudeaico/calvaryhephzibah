// preload.js — the only bridge between the untrusted renderer (the
// HTML/CSS/JS you'd normally see in a browser tab) and the main
// process's native NDI access. Keeps nodeIntegration off in the
// renderer, which is good practice even for an internal tool.

const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('ndi', {
  findSources: (waitMs) => ipcRenderer.invoke('ndi:find-sources', waitMs),
  connect: (source) => ipcRenderer.invoke('ndi:connect', source),
  disconnect: () => ipcRenderer.invoke('ndi:disconnect'),
  onFrame: (callback) => {
    ipcRenderer.on('ndi:frame', (_event, frame) => callback(frame));
  },
  onError: (callback) => {
    ipcRenderer.on('ndi:error', (_event, message) => callback(message));
  },
});
