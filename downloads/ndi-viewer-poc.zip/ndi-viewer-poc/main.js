// main.js — Electron main process.
//
// Runs the actual NDI find/receive against grandiose's native binding
// (this is the whole point of the "desktop app" approach: this native
// call is something a browser tab can never do). The renderer never
// touches grandiose directly — it just asks for sources and frames
// over IPC and draws whatever it's given.
//
// NOTE: written against grandiose's documented API. Not run/tested
// here (no macOS, no camera, no NDI network in this environment) —
// the first `npm start` on the actual machine is the real test.

const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');

let grandiose;
try {
  grandiose = require('grandiose');
} catch (err) {
  console.error('Could not load grandiose. Did `npm install` finish cleanly?', err);
}

let mainWindow;
let activeReceiver = null;
let receiveLoopActive = false;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1120,
    height: 680,
    backgroundColor: '#0A0A0A',
    title: 'Calvary NDI Viewer (proof of concept)',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });
  mainWindow.loadFile('renderer.html');
}

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  stopReceiving();
  if (process.platform !== 'darwin') app.quit();
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});

// ------------------------------------------------------------
// Find NDI sources on the local network
// ------------------------------------------------------------
ipcMain.handle('ndi:find-sources', async (_event, waitMs = 4000) => {
  if (!grandiose) throw new Error('grandiose failed to load — see main process console.');
  const sources = await grandiose.find({ showLocalSources: true }, waitMs);
  // Only pass plain serialisable data to the renderer
  return sources.map((s) => ({ name: s.name, urlAddress: s.urlAddress }));
});

// ------------------------------------------------------------
// Connect to a chosen source and start streaming frames to the
// renderer over IPC until stopped or replaced.
// ------------------------------------------------------------
ipcMain.handle('ndi:connect', async (event, source) => {
  if (!grandiose) throw new Error('grandiose failed to load — see main process console.');
  await stopReceiving();

  activeReceiver = await grandiose.receive({
    source,
    // Ask the SDK to hand back frames already in RGBA byte order so
    // the renderer can draw them straight into a canvas ImageData
    // with no colour-space conversion on our side.
    colorFormat: grandiose.COLOR_FORMAT_UYVY_RGBA,
    bandwidth: grandiose.BANDWIDTH_HIGHEST,
  });

  receiveLoopActive = true;
  const sender = event.sender;

  (async function receiveLoop() {
    let frameCount = 0;
    let lastFpsTick = Date.now();

    while (receiveLoopActive && activeReceiver) {
      try {
        const frame = await activeReceiver.video();
        if (!frame || !frame.data) continue;

        frameCount += 1;
        const now = Date.now();
        let fps = null;
        if (now - lastFpsTick >= 1000) {
          fps = frameCount;
          frameCount = 0;
          lastFpsTick = now;
        }

        if (sender.isDestroyed()) break;
        sender.send('ndi:frame', {
          width: frame.xres,
          height: frame.yres,
          buffer: frame.data, // Buffer — Electron structured-clones this fine
          fps,
        });
      } catch (err) {
        if (!sender.isDestroyed()) {
          sender.send('ndi:error', String((err && err.message) || err));
        }
        break;
      }
    }
  })();

  return true;
});

ipcMain.handle('ndi:disconnect', async () => {
  await stopReceiving();
  return true;
});

async function stopReceiving() {
  receiveLoopActive = false;
  if (activeReceiver) {
    try {
      // grandiose receivers don't always expose an explicit close();
      // dropping the reference lets the native object release on GC.
      if (typeof activeReceiver.close === 'function') {
        await activeReceiver.close();
      }
    } catch (err) {
      console.warn('Error closing NDI receiver:', err);
    } finally {
      activeReceiver = null;
    }
  }
}
